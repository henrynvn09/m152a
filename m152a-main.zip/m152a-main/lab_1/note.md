## workshop 2 

1. Part send to UUT: 24 
2. 
